import React from 'react'

export const ContactUs = () => {
  return (
    <div>ContactUs</div>
  )
}

export default ContactUs